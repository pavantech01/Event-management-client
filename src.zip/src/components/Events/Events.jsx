// import React, { useState, useEffect } from 'react';
// import axios from 'axios';

// const Events = () => {
//     const [events, setEvents] = useState([]);
//     const [error, setError] = useState('');

//     useEffect(() => {
//         const fetchEvents = async () => {
//             try {
//                 const response = await axios.get('http://localhost:5000/api/events');
//                 setEvents(response.data);
//             } catch (err) {
//                 setError('Failed to fetch events.');
//             }
//         };

//         fetchEvents();
//     }, []);

//     const handleDelete = async (eventId) => {
//         try {
//             await axios.delete(`http://localhost:5000/api/events/${eventId}`);
//             setEvents(events.filter(event => event.id !== eventId));
//         } catch (err) {
//             setError('Failed to delete event.');
//         }
//     };

//     return (
//         <div className="max-w-6xl mx-auto p-6">
//             <h1 className="text-4xl font-bold text-center mb-8">Upcoming Events</h1>
//             {error && <p className="text-red-500">{error}</p>}
//             <ul className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 list-none">
//                 {events.map(event => (
//                     <li key={event.id} className="bg-white shadow-lg rounded-lg p-4 transition-transform transform hover:scale-105">
//                         <img src={event.imageUrl} alt={event.title} className="w-full h-32 object-cover rounded-t-lg" />
//                         <h2 className="text-xl font-semibold mt-2">{event.title}</h2>
//                         <p className="text-gray-600">{event.description}</p>
//                         <button onClick={() => handleDelete(event.id)} className="mt-2 px-4 py-2 font-bold text-white bg-red-500 rounded-lg hover:bg-red-600">
//                             Delete
//                         </button>
//                     </li>
//                 ))}
//             </ul>
//         </div>
//     );
// };

// export default Events;
import React, { useState, useEffect } from 'react';
import axios from 'axios';

const Events = () => {
    const [events, setEvents] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState('');

    useEffect(() => {
        const fetchEvents = async () => {
            try {
                setLoading(true);
                const response = await axios.get('http://localhost:5000/api/events');
                // Ensure we're setting the events array from the response
                setEvents(response.data.events || []);
            } catch (err) {
                console.error('Error fetching events:', err);
                setError('Failed to fetch events.');
            } finally {
                setLoading(false);
            }
        };

        fetchEvents();
    }, []);

    const handleDelete = async (eventId) => {
        try {
            await axios.delete(`http://localhost:5000/api/events/${eventId}`);
            setEvents(events.filter(event => event._id !== eventId)); // Note: Using _id instead of id
        } catch (err) {
            setError('Failed to delete event.');
        }
    };

    if (loading) return (
        <div className="flex justify-center items-center min-h-screen">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500"></div>
        </div>
    );

    if (error) return (
        <div className="text-center text-red-500 p-4">
            {error}
        </div>
    );

    return (
        <div className="max-w-6xl mx-auto p-6">
            <h1 className="text-4xl font-bold text-center mb-8">Upcoming Events</h1>
            {events.length === 0 ? (
                <p className="text-center text-gray-500">No events available.</p>
            ) : (
                <ul className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 list-none">
                    {events.map(event => (
                        <li key={event._id} className="bg-white shadow-lg rounded-lg overflow-hidden">
                            <div className="w-full h-48 bg-gray-200">
                                {event.imageUrl ? (
                                    <img 
                                        src={event.imageUrl} 
                                        alt={event.title} 
                                        className="w-full h-full object-cover"
                                    />
                                ) : (
                                    <div className="w-full h-full flex items-center justify-center text-gray-400">
                                        No Image Available
                                    </div>
                                )}
                            </div>
                            <div className="p-4">
                                <h2 className="text-xl font-semibold mb-2">{event.title}</h2>
                                <p className="text-gray-600 mb-2">{event.description}</p>
                                <p className="text-sm text-gray-500 mb-2">
                                    Date: {new Date(event.date).toLocaleDateString()}
                                </p>
                                <p className="text-sm text-gray-500 mb-4">
                                    Location: {event.location}
                                </p>
                                <button 
                                    onClick={() => handleDelete(event._id)}
                                    className="w-full px-4 py-2 font-bold text-white bg-red-500 rounded-lg hover:bg-red-600 transition-colors"
                                >
                                    Delete
                                </button>
                            </div>
                        </li>
                    ))}
                </ul>
            )}
        </div>
    );
};

export default Events;